"""Utils package.

This package is for code shared by the Manager and the Worker.
"""
